<?php
session_start();

if (!isset($_SESSION['u_username']) || $_SESSION['u_type_name'] != "Admin" ) {
    include_once './redirect-to-index.inc.php';
    exit();
}  

if (isset($_POST['register'])) {
  $_SESSION['show_register_modal'] = false;
    
    // Connect to the databaase 
    include_once 'dbh.inc.php';
    
    // Escape the text data
    $user_first = pg_escape_string($dbconn, $_POST['user_first']);
    $user_last = pg_escape_string($dbconn, $_POST['user_last']);
    $user_email = pg_escape_string($dbconn, $_POST['user_email']);
    $user_type_id = pg_escape_string($dbconn, $_POST['user_type_id']);
    $user_username = pg_escape_string($dbconn, $_POST['user_username']);
    $user_pwd = pg_escape_string($dbconn, $_POST['user_pwd']);
    $user_pwd_confirm = pg_escape_string($dbconn, $_POST['user_pwd_confirm']);
        
    // Error handlers
    // Check for empty fields
    if (empty($user_first) || empty($user_last) || empty($user_email) || empty($user_type_id) || empty($user_username) 
        || empty($user_pwd) || empty($user_pwd_confirm)) 
    {
        header("Location: ../register.php?register=empty");
        exit();
    } else{

        $sql = "SELECT * FROM users WHERE user_username = '$user_username' OR user_email = '$user_email';";
        $result = pg_query($dbconn, $sql);
        
        // Check query error
        if (!$result) {
          echo "An error occurred.\n";
          exit;
        }
        
        // Get the results from the query
        $resultCheckRows = pg_num_rows($result);
        echo "<br>" . $resultCheckRows . " row(s) returned.\r\n"; // DEBUG
        
        // Check if the username matches any row in user_username field. 
        if ($resultCheckRows > 0){ 
            //if the username already exists -> then go back to register.php and modal popups!!           
            $_SESSION['show_register_modal'] = true; 
            
            header("Location: ../register.php?register=error");
            exit();
        } //end of if ($resultCheckRows > 0)
        else{
            //Hashing the password
             $hashedPwdCheck = password_hash($user_pwd, PASSWORD_DEFAULT);
            //Insert the user into the database
            $sql = "INSERT INTO Users (user_username, user_first, user_last, user_pwd, user_email, user_type_id)
            VALUES ('$user_username', '$user_first', '$user_last', '$hashedPwdCheck', '$user_email', '$user_type_id'); ";
            $result = pg_query($dbconn, $sql);
            
            // Check query error
            if (!$result) {
              echo "An error occurred.\n";
              exit;
            }

            // ******************************************************************************** //
            // ************* Log the action taken ********************************************* //
            // ******************************************************************************** //
            $sql_log = "INSERT INTO User_logs (user_ID, role, user_username, action_taken)
                                VALUES (".$_SESSION['u_id'].", '".$_SESSION['u_type_name']."',
                                '".$_SESSION['u_username']."','Create a new user:  username = ''" . $user_username . "'' ');";
            pg_query($dbconn, $sql_log);
            // ******************************************************************************** //
            // ******************************************************************************** //
           
            header("Location: ../display-user-table.php?register=usertaken.success");
            exit();
        }
    }   
} else {
    header("Location: ../register.php?attempt=fails");
    exit();
}
?>
    