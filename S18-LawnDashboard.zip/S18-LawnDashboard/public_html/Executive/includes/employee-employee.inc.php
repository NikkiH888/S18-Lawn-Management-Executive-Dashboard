<?php
session_start();
include_once './includes/redirect-to-index.inc.php';

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql_manager = "SELECT E.employee_id, E.employee_name, B.branch_name
                FROM Employee E, Branch B
                WHERE E.branch_id = B.branch_id
                ORDER BY E.employee_id;";



$result_manager = pg_query($dbconn, $sql_manager);

//Check query error
if (!$result_manager) {
    echo "An error occurred. --Manager\n";
    exit;
}
?>



<style>
    
.goog-combobox .goog-menu.goog-menu-vertical {
    overflow: scroll;
    height: 200px;
    right: 0px;
}

</style>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    
    google.charts.load('current', {'packages':['corechart', 'table', 'bar', 'gauge', 'controls']});

    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(drawMainDashboard_employee);

    function drawMainDashboard_employee() {

        var dashboard = new google.visualization.Dashboard(
            document.getElementById('dashboard_div_employee'));

        var categoryPicker_employee = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryPicker_div_employee_id',
            'state': {'selectedValues': ['ALL']},
            'options': {
                'filterColumnIndex': 0,
                'ui': {

                    'label': 'Employee Selection:',
                    'caption': 'All',
                    'allowTyping': true,
                    'allowMultiple': false,
                }
            }
        });
        
        var categoryPicker_employee_name = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryPicker_div_employee_name',
            'options': {
                'filterColumnIndex': 1,
                'ui': {

                    'label': 'Search Name:',
                    'caption': 'Search',
                    'allowTyping': true,
                    'allowMultiple': false,
                }
            }
        });

        var categoryPicker_employee_branch = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryPicker_div_employee_branch',
            'options': {
                'filterColumnIndex': 2,
                'ui': {

                    'label': 'Branch Selection:',
                    'caption': 'All',
                    'allowTyping': false,
                    'allowMultiple': false,
                }
            }
        });

        var table_employee = new google.visualization.ChartWrapper({
            'chartType': 'Table',
            'containerId': 'table_div_employee',
            'options': {
                'title': 'Employee',
                'width': 550,
                'height': 370,

            }
        });

        var data_manager = google.visualization.arrayToDataTable([
            ['Employee ID', 'Employee Name', 'Branch'],
            <?php
            while($row_manager = pg_fetch_array($result_manager))
            {
           eval("echo ' [\" ".$row_manager[0]." \", \"" .addslashes($row_manager[1]). "\", \" ".$row_manager[2]." \" ],'; ");
            }
  
            ?>
        ]);

        dashboard.bind([categoryPicker_employee, categoryPicker_employee_name, categoryPicker_employee_branch], table_employee);
        dashboard.draw(data_manager);
    }

</script>

<style>
    .google-visualization-table-td {
        text-align: center !important;
    }
</style> 




