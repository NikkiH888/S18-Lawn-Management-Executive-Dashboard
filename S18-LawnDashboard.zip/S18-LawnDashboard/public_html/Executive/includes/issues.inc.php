<?php
session_start();

// Check if the username is set, then redirect -to- index page
include_once './includes/redirect-to-index.inc.php';

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT iss.issueStatus_name AS status, COUNT(*) AS count
        FROM Issues i
        JOIN Issue_status iss ON i.issueStatus_ID = iss.issueStatus_ID
        GROUP BY (iss.issueStatus_name)";

$result = pg_query($dbconn,  $sql);

if (!$result) {
    echo "An error occurred.\n";
    exit;
}
?>

<script type="text/javascript">
    window.onload = function () {

        CanvasJS.addColorSet("barShades",
        [//colorSet Array
            "#007bff",
            "#dc3545",
            "#17a2b8",
        ]);
        
        var chart = new CanvasJS.Chart("chartContainer",{
            
            colorSet: "barShades",
            
            title:{
                text: " Property Issues "              
            },
            axisX:{
                labelBackgroundColor: "white",
                labelFontColor: "black"
            },
            data: [{
                // Change type to "bar", "area", "spline", "pie",etc.
                type: "column",
                dataPoints: [
                    
                    <?php
                    $data = pg_fetch_all($result);
                    $map = array();
                    foreach ($data as $row) {
                     $map[$row["status"]] = $row["count"];   
                    }
                    
                    $closed  = array_key_exists("Closed", $map) ? $map["Closed"] : 0;
                    $pastdue = array_key_exists("Past_Due", $map) ? $map["Past_Due"] : 0;
                    $open    = array_key_exists("Open", $map) ? $map["Open"] : 0;


                    echo "{label: 'Closed Issues', y: " . $closed . "},
                    {label: 'Past Due Issues', y: " . $pastdue . "},
                    {label: 'Open Issues', y: " . $open . "}";
                    ?>
                ]
            }
                  ]
        });
        chart.render();
    }
</script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>