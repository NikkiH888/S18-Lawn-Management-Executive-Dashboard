<?php
session_start(); // to access global variables
include_once './includes/redirect-to-index.inc.php';   

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT SUM(actLabor_expense) AS act_labor, SUM(actSubcontractor_expense) AS act_subcontractor, SUM(actMaterial_expense) AS act_material, SUM(actEquipment_expense) AS act_equipment,SUM(estLabor_expense) AS est_labor, SUM(estSubcontractor_expense) AS est_subcontractor, SUM(estMaterial_expense) AS est_material, SUM(estEquipment_expense) AS est_equipment FROM ticket;";



$sql2 = "SELECT c.property_id, SUM(actLabor_expense) AS act_labor, SUM(actSubcontractor_expense) AS act_subcontractor, SUM(actMaterial_expense) AS act_material, SUM(actEquipment_expense) AS act_equipment,
SUM(estLabor_expense) AS est_labor, SUM(estSubcontractor_expense) AS est_subcontractor, SUM(estMaterial_expense) AS est_material, SUM(estEquipment_expense) AS est_equipment
FROM ticket t
JOIN contractservice cs ON t.contractService_ID = cs.contractService_ID
JOIN contract c ON cs.contract_id = c.contract_id
GROUP BY c.property_id
ORDER BY c.property_id ASC;";



$result = pg_query($dbconn, $sql);
$result2 = pg_query($dbconn, $sql2);

//Check query error
if (!$result || !$result2) {
    echo "An error occurred.\n";
    exit;
}


?>


<style>
    
.goog-menu.goog-menu-vertical {
    overflow: scroll;
    height: 200px;
    right: 0px;
}

</style>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


<!--====================================================================================================-->
<!--====================================================================================================-->


<script type="text/javascript">

    // Load the Visualization API and the controls package.
    // Packages for all the other charts you need will be loaded
    // automatically by the system.
    google.charts.load('current', {'packages':['corechart', 'table', 'bar', 'gauge', 'controls']});


    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(drawMainDashboard);
    
    // Callback that creates and populates a data table,
    // instantiates a dashboard, a range slider and a pie chart,
    // passes in the data and draws it.
    function drawMainDashboard() {
        
        var dashboard = new google.visualization.Dashboard(
            document.getElementById('dashboard_div'));       
        
        var categoryPicker = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryPicker_div',
            'state': {'selectedValues': ['561']},
            'options': {
                'filterColumnIndex': 3,
                'ui': {
                    'label': 'Property Selection:',
                    'caption': 'Property ID:',
                    'allowTyping': true,
                    'allowMultiple': false,
                    'allowNone': false,
                    'sortValues': true,
                }
            }
            
        });
        
        var column = new google.visualization.ChartWrapper({
            'chartType': 'ColumnChart',
            'containerId': 'chart_div',
            'options': {
                legend: 'bottom',
            },
            'view': {'columns': [0, 1, 2]}
        });
        
        var data = google.visualization.arrayToDataTable([
            ['Type_Expense', 'Estimated Expense', 'Actual Expense', 'Property'],

            <?php
            while($row = pg_fetch_assoc($result2)) 
            {   
                $laborTotal = $row["est_labor"] + $row["act_labor"];
                $estLabor = $row["est_labor"] / $laborTotal * 100;
                $actLabor = $row["act_labor"] / $laborTotal * 100;

                $subcontractorTotal = $row["est_subcontractor"] + $row["act_subcontractor"];
                $estSubcontractor = $row["est_subcontractor"] / $subcontractorTotal * 100;
                $actSubcontractor = $row["act_subcontractor"] / $subcontractorTotal * 100;

                $materialTotal = $row["est_material"] + $row["act_material"];
                $estMaterial = $row["est_material"] / $materialTotal * 100;
                $actMaterial = $row["act_material"] / $materialTotal * 100;

                $equipmentTotal = $row["est_equipment"] + $row["act_equipment"];
                $estEquipment = $row["est_equipment"] / $equipmentTotal * 100;
                $actEquipment = $row["act_equipment"] / $equipmentTotal * 100;

                if (is_nan($estLabor)) $estLabor = 0;
                if (is_nan($actLabor)) $actLabor = 0;
                if (is_nan($estSubcontractor)) $estSubcontractor = 0;
                if (is_nan($actSubcontractor)) $actSubcontractor = 0;
                if (is_nan($estMaterial)) $estMaterial = 0;
                if (is_nan($actMaterial)) $actMaterial = 0;
                if (is_nan($estEquipment)) $estEquipment = 0;
                if (is_nan($actEquipment)) $actEquipment = 0;

                $property = $row["property_id"];
                echo "['Labor', $estLabor, $actLabor, '$property'],
                ['Subcontractor', $estSubcontractor, $actSubcontractor, '$property'],
                ['Material', $estMaterial, $actMaterial, '$property'],
                ['Equipment', $estEquipment, $actEquipment, '$property'],";

            } // End of while 
            ?>
            
       
            
            
        ]);
        
        
        dashboard.bind(categoryPicker, column);
        dashboard.draw(data);
    }
    
    
</script>





<!--====================================================================================================-->
<!--====================================================================================================-->

<style>
.google-visualization-table-td {
text-align: center !important;
}
</style>
        
        
        
        