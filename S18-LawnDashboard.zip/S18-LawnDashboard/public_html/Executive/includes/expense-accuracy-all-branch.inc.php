<?php
session_start(); // to access global variables
include_once './includes/redirect-to-index.inc.php';   

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT SUM(actLabor_expense) AS act_labor, SUM(actSubcontractor_expense) AS act_subcontractor, SUM(actMaterial_expense) AS act_material, SUM(actEquipment_expense) AS act_equipment,SUM(estLabor_expense) AS est_labor, SUM(estSubcontractor_expense) AS est_subcontractor, SUM(estMaterial_expense) AS est_material, SUM(estEquipment_expense) AS est_equipment FROM ticket;";


$result = pg_query($dbconn, $sql);

//Check query error
if (!$result) {
    echo "An error occurred.\n";
    exit;
}


?>


<style>
    
.goog-menu.goog-menu-vertical {
    overflow: scroll;
    height: 200px;
    right: 0px;
}

</style>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


<script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {

        
         <?php
            $row = pg_fetch_array($result);
        
            $laborTotal = $row["est_labor"] + $row["act_labor"];
            $estLabor = $row["est_labor"] / $laborTotal * 100;
            $actLabor = $row["act_labor"] / $laborTotal * 100;
        
            $subcontractorTotal = $row["est_subcontractor"] + $row["act_subcontractor"];
            $estSubcontractor = $row["est_subcontractor"] / $subcontractorTotal * 100;
            $actSubcontractor = $row["act_subcontractor"] / $subcontractorTotal * 100;
            
            $materialTotal = $row["est_material"] + $row["act_material"];
            $estMaterial = $row["est_material"] / $materialTotal * 100;
            $actMaterial = $row["act_material"] / $materialTotal * 100;
        
            $equipmentTotal = $row["est_equipment"] + $row["act_equipment"];
            if ($equipmentTotal <= 0) {
                $estEquipment = 0;
                $actEquipment = 0;
            }
            else {
                $estEquipment = $row["est_equipment"] / $equipmentTotal * 100;
                $actEquipment = $row["act_equipment"] / $equipmentTotal * 100;
            }
            
        ?>
        
        
        var  data_accuracy_of_all = google.visualization.arrayToDataTable([
            ['Type_Expense', 'Estimated Expense', 'Actual Expense'],

            ['Labor', <?= $estLabor ?>, <?= $actLabor ?>],
            ['Subcontractor', <?= $estSubcontractor ?>, <?= $actSubcontractor ?>],
            ['Material', <?= $estMaterial ?>, <?= $actMaterial ?>],

            ['Equipment', <?= $estEquipment ?>, <?= $actEquipment ?>],


            
        ]);

        var options = {
            
             legend: { position: "bottom" },
            
            chart: {
                
            },
        };

        var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
        chart.draw(data_accuracy_of_all, options);
        //chart.draw(data_accuracy_of_all, google.charts.Bar.convertOptions(options));
    }
</script>