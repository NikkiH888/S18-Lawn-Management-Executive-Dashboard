<?php 
session_start();
include_once './includes/redirect-to-index.inc.php';

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT l.lead_ID, b.branch_name, e.employee_name, i.industry_name, 
        lt.leadType_name, ls.leadStatus_name, l.leadValue, l.leadYear
        FROM Lead l
        JOIN Branch b ON l.branch_ID = b.branch_ID
        JOIN Employee e ON l.marketingRep_ID = e.employee_ID
        JOIN Industry i ON l.industry_ID = i.industry_ID
        JOIN Lead_type lt ON l.leadType_ID = lt.leadType_ID
        JOIN Lead_Status ls ON l.leadStatus_ID = ls.leadStatus_ID
        ;";

$result = pg_query($dbconn , $sql);


//Check query error
if (!$result) {
    echo "An error occurred.\n";
    exit;
}

while($row = pg_fetch_array($result, null, PGSQL_NUM)) {
    echo "
            <tr style='font-family:FontAwesome'>
            
                <td class='text-center' >" . $row[0] . "</td>
                <td>" . $row[1] . "</td>
                <td>" . $row[2] . "</td>
                <td>" . $row[3] . "</td>
                <td>" . $row[4] . "</td>
                <td>" . $row[5] . "</td>
                <td>" . $row[6] . "</td>
                <td>" . $row[7] . "</td>
             
            </tr>      
        ";
} // End of while loop
?>