<?php
session_start();
include_once './includes/redirect-to-index.inc.php';

//Connect to the databaase 
include_once 'dbh.inc.php';

//# Company Performance -> Net_income = revenue - cost | Net_sales = revenue | Profit Margin = (net_income/net_sales)
$sql = " SELECT (SUM(sale_price) - SUM(actualCost)), 
                 SUM(sale_price), 
                 (SUM(sale_price) - SUM(actualCost)) / SUM(sale_price)                     
         FROM Contract;";
$result = pg_query($dbconn, $sql);

//Check query error
if (!$result) {
    echo "An error occurred.\n";
    exit;
}

// Get the associated username
$row = pg_fetch_array($result);
echo '
                    <div class="row" style="padding-left: 200px">
                        <div class="col-sm-3 text-center my-auto" style="font-family:FontAwesome">
                            <div class="h4 mb-0 text-primary">$'. number_format($row[0],2) .'</div>
                            <div class="small text-muted">Current Total Company</div>
                            <div class="small text-muted">Net Income</div>
                        </div>
                        <div class="vl"></div>
                        <div class="col-sm-3 text-center my-auto" style="font-family:FontAwesome">
                            <div class="h4 mb-0 text-info">$'. number_format($row[1],2) .'</div>
                            <div class="small text-muted">Current Total Company</div>
                            <div class="small text-muted">Net Sales (revenue)</div>
                        </div>
                        <div class="vl"></div>
                        <div class="col-sm-3 text-center my-auto" style="font-family:FontAwesome">
                            <div class="h4 mb-0 text-success">'. number_format($row[2] * 100,2) .'%</div>
                            <div class="small text-muted">Company</div>
                            <div class="small text-muted">Profit Margin</div>
                        </div>
                    </div>

  ';
?>
