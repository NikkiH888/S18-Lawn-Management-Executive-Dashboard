<?php
session_start();
include_once './includes/redirect-to-index.inc.php';

session_start();
// Check if the username is set, then redirect -to- dashboard page
if(!isset($_SESSION['u_username'])) {
    header("Location: ../../homepage-index.php?access=failed");
    exit();
}

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT B.Branch_name, C.contractYear, SUM(sale_price),  SUM(actualCost)
        FROM Contract C, Property P,  Branch B
        WHERE C.property_ID = P.property_ID AND P.branch_ID = B.branch_ID
        GROUP BY B.Branch_ID, C.contractYear;";


$result = pg_query($dbconn, $sql);


//Check query error
if (!$result || !$result2) {
    echo "An error occurred.\n";
    exit;
}

?>


<style>
.vl {
    border-left: 1px solid black;
    height: 50px;
}
</style>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">

    // Load the Visualization API and the controls package.
    // Packages for all the other charts you need will be loaded
    // automatically by the system.
    google.charts.load('current', {'packages':['corechart', 'table', 'bar', 'gauge', 'controls']});


    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(drawMainDashboard);
    
    // Callback that creates and populates a data table,
    // instantiates a dashboard, a range slider and a pie chart,
    // passes in the data and draws it.
    function drawMainDashboard() {
        
        var dashboard = new google.visualization.Dashboard(
            document.getElementById('dashboard_div'));
        
        var control = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryFilter_control_div',
            'options': {
                'filterColumnIndex': 0,
                'ui': {
                    'label': 'Branch Selection:',
                    'caption': 'Branch',
                    'allowTyping': false,
                    'allowMultiple': true,
                    'selectedValuesLayout': 'aside'
                }
                
            }
        });
        
        
        var categoryPicker = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryPicker_div',
            'state': {'selectedValues': ['2011']},
            'options': {
                'filterColumnIndex': 1,
                'ui': {
                    'label': 'Year Selection:',
                    'caption': 'All Year',
                    'allowTyping': false,
                    'allowMultiple': false,
                    'allowNone': false,
                }
            }
        });
        
        var column = new google.visualization.ChartWrapper({
            'chartType': 'Bar',
            'containerId': 'chart_div',
            'options': {
                title: 'Branch Performance',
                'width': 600,
                'height': 400,
                vAxis: {title: 'Total Dollars'},
                hAxis: {
                    title: 'Branch',
                    viewWindowMode: 'pretty',
                    viewWindow: {
                        min: [7, 30, 0],
                        max: [17, 30, 0]
                    },
                    textStyle: {
                        fontSize: 14,
                        color: '#053061',
                        bold: true,
                        italic: false
                    },
                    titleTextStyle: {
                        fontSize: 18,
                        color: '#053061',
                        bold: true,
                        italic: false
                    }
                },

            },
            'view': {'columns': [0, 2, 3, ]}
        });
        
        var table = new google.visualization.ChartWrapper({
            'chartType': 'Table',
            'containerId': 'table_div',
            'options': {
                'title': 'Countries',
                'width': 300,
                'height': 200,
                
            }
        });
        
        var data = google.visualization.arrayToDataTable([
            ['Branch', 'Year', '$Revenue', '$Expense'],
            ['Kansas City', '2011', 132000.09, 90000],
            <?php
            while($row = pg_fetch_array($result))
            {
                echo "['" . $row[0] . "', '" . $row[1] . "', " . $row[2] . ", " . $row[3] ."],";
            }
            ?>

            
        ]);
        
        
        dashboard.bind([control, categoryPicker], [column, table]);
        dashboard.draw(data);
    }
    
    
</script>
<style>
.google-visualization-table-td {
text-align: center !important;
}
</style>
        
        
        
        