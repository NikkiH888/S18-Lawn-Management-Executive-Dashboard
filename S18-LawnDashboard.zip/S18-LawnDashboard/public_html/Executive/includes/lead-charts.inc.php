<?php 
session_start();
include_once './includes/redirect-to-index.inc.php';

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT b.branch_name, count(l.lead_ID)
        FROM Lead l, branch b
        WHERE l.branch_id = b.branch_id
        GROUP BY b.branch_id;";

$sql2 = "SELECT i.industry_name, count(l.lead_ID)
         FROM Lead l, industry i
         WHERE l.industry_id = i.industry_id AND l.leadStatus_ID  IN (2,4)
         GROUP BY i.industry_id;";

$sql3 = "SELECT leadYear, count(lead_ID)
         FROM lead
         WHERE leadStatus_ID  IN (2,4)
         GROUP BY leadYear
         ORDER BY leadYear ASC;";


$result = pg_query($dbconn,  $sql);
$result2 = pg_query($dbconn, $sql2);
$result3 = pg_query($dbconn, $sql3);


if (!$result || !$result2 || !$result3) {
    echo "An error occurred.\n";
    exit;
}

?>


<script type="text/javascript">  
  
    window.onload = function () {

        CanvasJS.addColorSet("barShades1",
        [//colorSet Array
            "#00A572",
        ]);

        CanvasJS.addColorSet("barShades2",
        [//colorSet Array
            "#8E44AD"  //persian
        ]);

        CanvasJS.addColorSet("barShades3",
        [//colorSet Array
            "#3498DB"  //persian
        ]);
        

        var by_branch = new CanvasJS.Chart("by-branch-bar-chart",
        {
            colorSet: "barShades1",
            dataPointMaxWidth: 46,
            axisY:{
                title:"Lead(s)",
            },
            data: [    
                {
                    dataPoints: [
                        <?php
                        $i=1;
                        while($row = pg_fetch_array($result, null, PGSQL_NUM)) {
                             echo '{ x: ' . $i . ', y: ' . $row[1] . ',  label: "' . $row[0] . '"},';
                            
                            $i = $i+1; // increment i counter for delete ID icons
                        } // End of while loop
                        ?>
                      
                    ]
                }
            ]
        });
        
        
        var by_industry = new CanvasJS.Chart("by-industry-bar-chart",
        {
            colorSet: "barShades2",
            dataPointMaxWidth: 46,
            axisY:{
                title:"Lead(s)",
            },
            data: [
                {
                    dataPoints: [

                        <?php
                        $i=1;
                        while($row = pg_fetch_array($result2, null, PGSQL_NUM)) {
                             echo '{ x: ' . $i . ', y: ' . $row[1] . ',  label: "' . $row[0] . '"},';
                            
                            $i = $i+1; // increment i counter for delete ID icons
                        } // End of while loop
                        ?>
                    ]
                }
            ]
        });

        
        var by_year = new CanvasJS.Chart("by-year-bar-chart",
        {
            colorSet: "barShades3",
            dataPointMaxWidth: 46,
            axisY:{
                title:"Lead(s)",
            },
            axisX:{
                title:"Year",
            },
            data: [
                {
                    dataPoints: [
                         <?php
                        $i=1;
                        while($row = pg_fetch_array($result3, null, PGSQL_NUM)) {
                             echo '{ x: ' . $i . ', y: ' . $row[1] . ',  label: "' . $row[0] . '"},';
                            
                            $i = $i+1; // increment i counter for delete ID icons
                        } // End of while loop
                        ?>

                    ]
                }
            ]
        });
           
  
        by_branch.render();
        by_industry.render();
        by_year.render();
    }
</script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>