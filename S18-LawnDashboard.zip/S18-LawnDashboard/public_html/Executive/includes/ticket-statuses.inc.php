<?php
session_start();
// Check if the username is set, then redirect -to- dashboard page
if(!isset($_SESSION['u_username'])) {
    header("Location: ../../homepage-index.php?access=failed");
    exit();
}

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT ts.ticketStatus_name AS status, COUNT(*)
        FROM Ticket t
        JOIN Ticket_status ts ON t.ticketStatus_ID = ts.ticketStatus_ID
        GROUP BY (ts.ticketStatus_name);";

$result = pg_query($dbconn,  $sql);

if (!$result) {
    echo "An error occurred.\n";
    exit;
}

?>

<script type="text/javascript">
    window.onload = function () {

        CanvasJS.addColorSet("barShades",
        [//colorSet Array
            "#28a745",
            "#17a2b8",
            "#007bff"
        ]);

        
        var chart = new CanvasJS.Chart("chartContainer",{
            
            colorSet: "barShades",
            
            title:{
                text: " Ticket Statuses "              
            },
            axisX:{
                labelBackgroundColor: "white",
                labelFontColor: "black"
            },
            data: [{
                
                
                
                // Change type to "bar", "area", "spline", "pie",etc.
                type: "column",
                dataPoints: [
                    
                    
                    
                    <?php
                        $data = pg_fetch_all($result);
                        $map = array();
                        foreach ($data as $row) {
                            $map[$row["status"]] = $row["count"];   
                        }

                        $closed = array_key_exists("Billed", $map) ? $map["Billed"] : 0;
                        $pastdue = array_key_exists("Approved", $map) ? $map["Approved"] : 0;
                        $open = array_key_exists("Open", $map) ? $map["Open"] : 0;
                    
                        $_SESSION['Billed_ticket'] = $closed;
                        $_SESSION['Approved_ticket'] = $pastdue;
                        $_SESSION['open_ticket'] = $open;

                        echo "{label: 'Billed Tickets', y: " . $closed . "},
                        {label: 'Approved Tickets',     y: " . $pastdue . "},
                        {label: 'Open Tickets',         y: " . $open . "}";

                    ?>

                    
                ]
            }
                  ]
        });
        chart.render();
    }
</script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>