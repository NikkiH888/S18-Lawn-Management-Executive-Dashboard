<?php 
session_start();
include_once './includes/redirect-to-index.inc.php';


//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT po.po_id, v.vendor_name, ps.status,
        b.branch_name, po.created_by_user_code, po.submitted_on,
        po.estimated_delivery_date, po.is_fully_allocated
        FROM PurchaseOrder po
        JOIN Vendor v ON po.vendor_ID = v.vendor_ID
        JOIN Purchase_status ps ON po.purchaseStatus_ID = ps.purchaseStatus_ID
        JOIN Branch b ON po.branch_ID = b.branch_ID
        WHERE ps.status = 'Approved' 
        LIMIT 1000";

//echo "<pre>".print_r($dbconn, true)."</pre>";
$result = pg_query($dbconn, $sql);

//Check query error
if (!$result) {
    echo "An error occurred.\n";
    exit;
}

while($row = pg_fetch_array($result, null, PGSQL_NUM)) {
    $isFullyAllocated = strcmp($row[7], 'f') === 0 ? "NO" : "YES";
    $estDelivery = empty($row[6]) ? "N/A" : $row[6];
    echo "
            <tr style='font-family:FontAwesome'>
            
                <td class='text-center' >" . $row[0] . "</td>
                <td>" . $row[1] . "</td>
                <td>" . $row[2] . "</td>
                <td>" . $row[3] . "</td>
                <td>" . $row[4] . "</td>
                <td>" . $row[5] . "</td>
                <td>" . $estDelivery . "</td>
                <td>" . $isFullyAllocated . "</td>
             
            </tr>      
        ";
} // End of while loop

?>