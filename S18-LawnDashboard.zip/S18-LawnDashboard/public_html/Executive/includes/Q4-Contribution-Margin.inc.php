<?php
session_start();
include_once './includes/redirect-to-index.inc.php';

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT contractyear, (1 - (sum(actualCost)/sum(sale_price))) * 100 AS Contribution_Margin
        FROM Contract
        GROUP BY contractyear
        ORDER BY contractyear;";


$result = pg_query($dbconn, $sql);

//Check query error
if (!$result) {
    echo "An error occurred.\n";
    exit;
}
?>


<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    
  google.charts.load('current', {'packages':['line']});
      google.charts.setOnLoadCallback(drawChart);

    function drawChart() {

      var data = new google.visualization.DataTable();
      data.addColumn('string', 'Year');
      data.addColumn('number', '% Contribution Margin');


      data.addRows([
          
      <?php

          while($row = pg_fetch_array($result))
          {
              echo "['" . $row[0] . "', " . number_format($row[1],2) ."],";
          }
          ?>
          

      ]);

      var options = {
        chart: {
          title: 'Contribution Margin of the Total Company Expense and Revenue of each Year',
          subtitle: 'in percent (%)'
        },
        width: 900,
        height: 500
      };

      var chart = new google.charts.Line(document.getElementById('linechart_material'));

      chart.draw(data, google.charts.Line.convertOptions(options));
    }
</script>