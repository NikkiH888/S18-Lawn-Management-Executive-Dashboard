<?php
session_start();
include_once './includes/redirect-to-index.inc.php';

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql_manager = "SELECT * FROM client_summary;";

$result_manager = pg_query($dbconn, $sql_manager);

//Check query error
if (!$result_manager) {
    echo "An error occurred. --Manager\n";
    exit;
}
?>

<style>
    
.goog-combobox .goog-menu.goog-menu-vertical {
    overflow: scroll;
    height: 200px;
    right: 0px;
}

</style>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    
    google.charts.load('current', {'packages':['corechart', 'table', 'bar', 'gauge', 'controls']});

    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(drawMainDashboard_employee);

    function drawMainDashboard_employee() {

        var dashboard = new google.visualization.Dashboard(
            document.getElementById('dashboard_div_employee'));

        var categoryPicker_employee = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryPicker_div_employee_id',
            'state': {'selectedValues': ['ALL']},
            'options': {
                'filterColumnIndex': 0,
                'ui': {
                    'label': 'Search Property:',
                    'caption': 'All',
                    'allowTyping': true,
                    'allowMultiple': false,
                }
            }
        });
        
        var categoryPicker_employee_name = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryPicker_div_employee_name',
            'options': {
                'filterColumnIndex': 2,
                'ui': {

                    'label': 'Search Client:',
                    'caption': 'Search',
                    'allowTyping': true,
                    'allowMultiple': false,
                }
            }
        });

        var categoryPicker_employee_branch = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryPicker_div_employee_branch',
            'options': {
                'filterColumnIndex': 1,
                'ui': {

                    'label': 'Branch Selection:',
                    'caption': 'All',
                    'allowTyping': false,
                    'allowMultiple': false,
                }
            }
        });
        
        var categoryPicker_industry = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryPicker_div_client_industry',
            'options': {
                'filterColumnIndex': 3,
                'ui': {

                    'label': 'Industry Selection:',
                    'caption': 'All',
                    'allowTyping': false,
                    'allowMultiple': false,
                }
            }
        });

        var table_client = new google.visualization.ChartWrapper({
            'chartType': 'Table',
            'containerId': 'table_div_employee',
            'options': {
                'title': 'client',
               
                'height': 370,

            }
        });

        var data_client = google.visualization.arrayToDataTable([
            ['Property Name', 'Branch', 'Client Name', 'Industry', 'Address Type', 'City', 'State'],
            <?php
            while($row_manager = pg_fetch_array($result_manager))
            {
                eval("echo ' [\"" .addslashes($row_manager[0]). "\", \" ".$row_manager[1]." \", 
                              \" ".$row_manager[2]." \", \"" .$row_manager[3]. "\", \" ".$row_manager[4]." \",
                              \" ".addslashes($row_manager[5])." \", \"" .addslashes($row_manager[6]). "\"
                            ],
                   '; 
               ");
            }

            ?>
           
        ]);

        dashboard.bind([categoryPicker_employee, categoryPicker_employee_name, categoryPicker_employee_branch, categoryPicker_industry], table_client);
        dashboard.draw(data_client);
    }

</script>

<style>
    .google-visualization-table-td {
        text-align: center !important;
    }
</style> 




