<?php 

session_start();

// Can be used only in same directory of index!!!! 
// Check if username is not set, then redirect -to- index page
if (!isset($_SESSION["u_username"])) {
    header("Location: /~bhv39/Executive/index.php?login=not.login");
    exit();
}
?>