<?php 
session_start();

include_once './redirect-to-index.inc.php';


//Connect to the databaase 
include_once 'dbh.inc.php';

$sql_new_lead = "SELECT count(*) FROM lead WHERE leadstatus_id = 4;";

$sql_open_ticket = "SELECT count(*) FROM Ticket WHERE ticketStatus_ID = 2;";
$sql_approved_ticket = "SELECT count(*) FROM Ticket WHERE ticketStatus_ID = 5;";
$sql_billed_ticket = "SELECT count(*) FROM Ticket WHERE ticketStatus_ID = 7;";

$sql_new_purchase = "SELECT count(*) FROM purchaseOrder WHERE purchaseStatus_ID = 1;";
$sql_approved_purchase = "SELECT count(*) FROM purchaseOrder WHERE purchaseStatus_ID = 5;";
$sql_complete_purchase = "SELECT count(*) FROM purchaseOrder WHERE purchaseStatus_ID = 6;";

$sql_open_issue = "SELECT count(*) FROM Issues WHERE issueStatus_ID = 1;";
$sql_closed_issue = "SELECT count(*) FROM Issues WHERE issueStatus_ID = 2;";
$sql_past_issue = "SELECT count(*) FROM Issues WHERE issueStatus_ID = 3;";





$result_new_lead = pg_query($dbconn, $sql_open_ticket);

$result_open_ticket = pg_query($dbconn, $sql_open_ticket);
$result_approved_ticket = pg_query($dbconn, $sql_approved_ticket);
$result_billed_ticket = pg_query($dbconn, $sql_billed_ticket);

$result_new_purchase = pg_query($dbconn, $sql_new_purchase);
$result_approved_purchase = pg_query($dbconn, $sql_approved_purchase);
$result_complete_purchase = pg_query($dbconn, $sql_complete_purchase);

$result_open_issue = pg_query($dbconn, $sql_open_issue);
$result_closed_issue = pg_query($dbconn, $sql_closed_issue);
$result_past_issue = pg_query($dbconn, $sql_past_issue);


//Check query error
if (!$result_new_lead || !$result_open_ticket || !$result_approved_ticket || !$result_billed_ticket
                      || !$result_new_purchase || !$result_approved_purchase || !$result_complete_purchase
                      || !$result_open_issue || !$result_closed_issue || !$result_past_issue) {
    echo "An error occurred. --After quering number of data\n";
    exit;
}


$row_new_lead = pg_fetch_array($result_new_lead);

$row_open_ticket = pg_fetch_array($result_open_ticket);
$row_approved_ticket = pg_fetch_array($result_approved_ticket);
$row_billed_ticket = pg_fetch_array($result_billed_ticket);

$row_new_purchase = pg_fetch_array($result_new_purchase);
$row_approved_purchase = pg_fetch_array($result_approved_purchase);
$row_complete_purchase = pg_fetch_array($result_complete_purchase);

$row_open_issue = pg_fetch_array($result_open_issue);
$row_closed_issue = pg_fetch_array($result_closed_issue);
$row_past_issue = pg_fetch_array($result_past_issue);


$_SESSION['new_lead'] = $row_new_lead[0];

$_SESSION['open_ticket'] = $row_open_ticket[0];
$_SESSION['approved_ticket'] = $row_approved_ticket[0];
$_SESSION['billed_ticket'] = $row_billed_ticket[0];

$_SESSION['new_purchase'] = $row_new_purchase[0];
$_SESSION['approved_purchase'] = $row_approved_purchase[0];
$_SESSION['complete_purchase'] = $row_complete_purchase[0];

$_SESSION['open_issue'] = $row_open_issue[0];
$_SESSION['closed_issue'] = $row_closed_issue[0];
$_SESSION['past_issue'] = $row_past_issue[0];

?>