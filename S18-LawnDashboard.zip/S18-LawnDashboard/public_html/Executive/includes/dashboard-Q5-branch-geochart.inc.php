<?php 
session_start();
include_once './includes/redirect-to-index.inc.php';

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT b.branch_name, count(p.property_ID) AS properties
        FROM branch b, Property P
        WHERE b.branch_ID = p.branch_ID
        GROUP BY b.branch_name;";

$result = pg_query($dbconn, $sql);

//Check query error
if (!$result) {
    echo "An error occurred.\n";
    exit;
}

?>

<script type='text/javascript' src='https://www.gstatic.com/charts/loader.js'></script>
<script type='text/javascript'>
    google.charts.load('current', {
        'packages': ['geochart'],
        // Note: you will need to get a mapsApiKey for your project.
        // See: https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings
        'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
    });
    google.charts.setOnLoadCallback(drawMarkersMap);

    function drawMarkersMap() {
        var data = google.visualization.arrayToDataTable([
            ['City',   '#Properties'],
   
            <?php
            while($row = pg_fetch_array($result))
            {
                echo "['" . $row[0] . "'," . $row[1] . "],";
            }
            ?>
            
        ]);

        var options = {
            region: 'US-MO',
            displayMode: 'markers', 
            resolution: 'provinces',
            colorAxis: {colors: ['green', 'blue']}
        };

        var chart = new google.visualization.GeoChart(document.getElementById('geoChart_div'));
        chart.draw(data, options);
    };
</script>