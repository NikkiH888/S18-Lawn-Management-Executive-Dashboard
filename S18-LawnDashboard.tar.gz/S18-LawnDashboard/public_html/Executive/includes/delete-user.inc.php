<?php
session_start();

if(!isset($_SESSION['u_username']) || $_SESSION['u_type_name'] != "Admin" ) {
    include_once './redirect-to-index.inc.php';
    exit();
}

if(isset($_POST['delete_user_id'])) {

    //Connect to the databaase
    include_once 'dbh.inc.php';
    
    $delete_user_id = pg_escape_string($_POST['delete_user_id']);
    $delete_user_username = pg_escape_string($_POST['delete_user_username']);

    $sql = "DELETE FROM Users WHERE user_id = " . $delete_user_id . ";";
    $result = pg_query($dbconn, $sql);
        
    //Check query error
    if (!$result) {
        echo "An error occurred -- after pg_query.\n";
        exit();
    }
   
    // ******************************************************************************** //
    // ************* Log the action taken ********************************************* //
    // ******************************************************************************** //
    $sql_log = "INSERT INTO User_logs (user_id, role, user_username, action_taken) 
                VALUES ('".$_SESSION['u_id']."', '".$_SESSION['u_type_name']."', 
                '".$_SESSION['u_username']."', 'Delete user = ''".$delete_user_username."'' ');";
    pg_query($dbconn, $sql_log);
    // ******************************************************************************** //
    // ******************************************************************************** //
    
    header("Location: ../display-user-table.php?delete=success");
    exit();
} else{
    header("Location: ../display-user-table.php?delete=error");
    exit();
}
?>