<?php
session_start();

if (!isset($_SESSION['u_username']) || $_SESSION['u_type_name'] != "Admin" ) {
    include_once './redirect-to-index.inc.php';
    exit();
}      
?>

<?php
//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT * 
        FROM User_logs
        ORDER BY action_taken_time DESC;";

$result = pg_query($dbconn, $sql);
    
//Check query error
if (!$result) {
    echo "An error occurred.--Select From User_logs\n";
    exit;
}

while($row = pg_fetch_array($result)) {
    echo "
            <tr>
                <td class='text-center' style='font-family:FontAwesome'>" . $row['user_id'] . "</td>
                <td style='font-family:FontAwesome' >" . $row['user_username'] . "</td> 
         ";
            
    if($row['role'] == "Admin"){       
    echo "      <td class='text-center' style='color:blue; font-family:courier;'>" . $row['role'] . "</td> 
         ";
    } 
    else {
    echo "      <td class='text-center' style='color:green; font-family:courier;'>" . $row['role'] . "</td> 
         ";
    }    
    echo "      <td class='text-center' style='font-family:FontAwesome'>" . $row['action_taken_time'] . "</td>
                <td style='font-family:courier;'>" . $row['action_taken'] . "</td>
            </tr>      
        "; 
          
} // End of while loop

$sql = "SELECT max(action_taken_time::timestamp(0))  FROM User_logs;";
$result = pg_query($dbconn, $sql);
$row = pg_fetch_assoc($result);
$_SESSION['latest_log'] = $row['max'];
?>