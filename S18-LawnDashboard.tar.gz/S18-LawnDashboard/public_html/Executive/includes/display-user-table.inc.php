<?php
session_start();

if (!isset($_SESSION['u_username']) || $_SESSION['u_type_name'] != "Admin" ) {
    include_once './redirect-to-index.inc.php';
    exit();
}

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT * FROM Users U, User_types Ut WHERE U.user_type_id = Ut.user_type_id;";
$result = pg_query($dbconn, $sql);
    
//Check query error
if (!$result) {
    echo "An error occurred.\n";
    exit();
}

$i=1;
while($row = pg_fetch_array($result)) {
    echo "
            <tr style='font-family:FontAwesome'>
                <td class='text-center' >" . $row['user_id'] . "</td>
                <td>" . $row['user_username'] . "</td>
                <td class='text-center'>***********</td>
                <td>" . $row['user_first'] . "</td>
                <td>" . $row['user_last'] . "</td>
                <td>" . $row['user_email'] . "</td>
                <td>" . $row['user_type_name'] . "</td>

                <td class='text-center'>
                    <form action='./display-user-table.php' method='POST' id='UpdateConfirm$i'>
                        <input type='hidden' name='userID'             value='" . $row['user_id'] . "'>
                        <input type='hidden' name='updateUsername'     value='" . $row['user_username'] . "'>    
                        <input type='hidden' name='updatePassword'     value='" . $row['user_pwd'] . "'>                        
                        <input type='hidden' name='updateFirstName'    value='" . $row['user_first'] . "'>
                        <input type='hidden' name='updateLastName'     value='" . $row['user_last'] . "'>
                        <input type='hidden' name='updateEmail'        value='" . $row['user_email'] . "'>
                        <input type='hidden' name='updateUserTypeID'   value='" . $row['user_type_id'] . "'>
                        <input type='hidden' name='updateUserTypeName' value='" . $row['user_type_name'] . "'>
                        <a data-placement='top' data-toggle='tooltip' title='Update User Info.'>
                            <button class='btn btn-warning btn-sm' type='submit' form='UpdateConfirm$i' name='Update'>
                            <span class='fa fa-edit'></span>
                            </button>
                        </a>
                    </form>
                </td> 

                <td class='text-center'> 
                    <form action='./display-user-table.php' method='POST' id='DeleteConfirm$i'>
                        <input type='hidden' name='delete_user_username'     value='" . $row['user_username'] . "'>  
                        <input type='hidden' name='delete_user_id' value='" . $row['user_id'] . "'>
                        <a data-placement='top' data-toggle='tooltip' title='Delete'>
                            <button class='btn btn-danger btn-sm' type='submit' form='DeleteConfirm$i' name='Delete'>
                            <span class='fa fa-trash'></span>
                            </button>
                        </a>
                    </form>
                </td> 
            </tr>      
        ";
    $i = $i+1; // increment i counter for delete ID icons
} // End of while loop

$sql = "SELECT max(updatedon::timestamp(0))  FROM Users;";
$result = pg_query($dbconn, $sql);
$row = pg_fetch_assoc($result);
$_SESSION['latest_user_upated_on'] = $row['max'];
?>