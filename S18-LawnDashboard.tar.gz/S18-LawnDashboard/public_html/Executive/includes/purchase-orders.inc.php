<?php

session_start();


// Check if the username is set, then redirect -to- dashboard page
include_once './includes/redirect-to-index.inc.php';


//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT ps.status, COUNT(*)
        FROM PurchaseOrder po
        JOIN Purchase_status ps ON po.purchaseStatus_ID = ps.purchaseStatus_ID
        GROUP BY (ps.status);";

$result = pg_query($dbconn,  $sql);

if (!$result) {
    echo "An error occurred.\n";
    exit;
}
?>

<script type="text/javascript">
    window.onload = function () {

        CanvasJS.addColorSet("barShades",
        [//colorSet Array
            "#28a745",
            "#007bff",
            "#17a2b8",
        ]);

        
        var chart = new CanvasJS.Chart("chartContainer",{
            
            colorSet: "barShades",
            
            title:{
                text: " Purchase Order Reports "              
            },
            axisX:{
                labelBackgroundColor: "white",
                labelFontColor: "black"
            },
            data: [{
                // Change type to "bar", "area", "spline", "pie",etc.
                type: "column",
                dataPoints: [

                    <?php
                    $data = pg_fetch_all($result);
                    $map = array();
                    foreach ($data as $row) {
                        $map[$row["status"]] = $row["count"];   
                    }

                    $closed = array_key_exists("Complete", $map) ? $map["Complete"] : 0;
                    $pastdue = array_key_exists("Approved", $map) ? $map["Approved"] : 0;
                    $open = array_key_exists("New", $map) ? $map["New"] : 0;

                    echo "{label: 'Completed Orders', y: " . $closed . "},
                    {label: 'Approved Orders', y: " . $pastdue . "},
                    {label: 'New Orders', y: " . $open . "}";

                    ?>

                ]
            }
                  ]
        });
        chart.render();
    }
</script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>