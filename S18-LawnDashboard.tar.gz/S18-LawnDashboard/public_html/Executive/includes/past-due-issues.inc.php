<?php
session_start();

// Check if the username is set, then redirect -to- index page
include_once './redirect-to-index.inc.php';    

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT i.issue_id, iss.issueStatus_name, e.employee_name, p.property_name, it.issueType_code, py.priority, i.dueDate
        FROM Issues i
        JOIN Issue_status iss ON i.issueStatus_ID = iss.issueStatus_ID
        JOIN Employee e ON i.assignedForeman_ID = e.employee_ID
        JOIN Property p ON i.property_ID = p.property_ID
        JOIN Issue_type it ON i.issueType_ID = it.IssueType_ID
        JOIN Priority py ON i.issuePriority_ID = py.issuePriority_ID
        WHERE iss.issueStatus_name = 'Past_Due'";

$result = pg_query($dbconn, $sql);
    
//Check query error
if (!$result) {
    echo "An error occurred.\n";
    exit;
}

$i=1;
while($row = pg_fetch_array($result, null, PGSQL_NUM)) {
    $duedate = empty($row[6]) ? "N/A" : $row[6];
    echo "
            <tr style='font-family:FontAwesome'>
            
                <td class='text-center' >" . $row[0] . "</td>
                <td>" . $row[1] . "</td>
                <td>" . $row[2] . "</td>
                <td>" . $row[3] . "</td>
                <td>" . $row[4] . "</td>
                <td>" . $row[5] . "</td>
                <td>" . $duedate . "</td>
             
            </tr>      
        ";
    $i = $i+1; // increment i counter for delete ID icons
} // End of while loop

?>