<?php

session_start();
    
// Check if the username is set, then redirect -to- index page
if(!isset($_SESSION['u_username']) || $_SESSION['u_type_name'] != "Admin" ) {
    include_once './redirect-to-index.inc.php';
}
    
if (isset($_POST['updateUserButton'])) {
    
    /****************************************************************************************/
    $_SESSION['show_update_modal'] = false;
    $_SESSION['isUsernameExisted'] = false;
    $_SESSION['isEmailExisted'] = false;
    /****************************************************************************************/  
    
    // Connect to the databaase 
    include_once 'dbh.inc.php';
    
    // Escape the text data
    $user_ID = pg_escape_string($dbconn, $_POST['userID']);
    $user_first = pg_escape_string($dbconn, $_POST['user_first']);
    $user_last = pg_escape_string($dbconn, $_POST['user_last']);
    $user_email = pg_escape_string($dbconn, $_POST['user_email']);
    $user_type_id = pg_escape_string($dbconn, $_POST['user_type_id']);
    $user_username = pg_escape_string($dbconn, $_POST['user_username']);
    $user_pwd = pg_escape_string($dbconn, $_POST['user_pwd']);
    $_SESSION['fail_user_id'] = $user_ID;  
    
    // Error handlers
    $sql_username = "SELECT * FROM users WHERE user_username = '$user_username';";
    $sql_email = "SELECT * FROM users WHERE user_email = '$user_email';";
    $result_username = pg_query($dbconn, $sql_username);
    $result_email = pg_query($dbconn, $sql_email);

    // Check query error
    if (!$result_username || !$result_email) {
        echo "An error occurred.\n";
        exit();
    } 
   
    // Get the results from the queries
    $resultCheckRows_username = pg_num_rows($result_username);
    $resultCheckRows_email = pg_num_rows($result_email);
    //echo "<br> Username:" . $resultCheckRows_username . " row(s) returned.\r\n"; // DEBUG
    //echo "<br> Email:" . $resultCheckRows_email . " row(s) returned.\r\n"; // DEBUG
    //exit();
    
    
    // Get the associated username
    $row_username = pg_fetch_assoc($result_username);

    // Get the associated email 
    $row_email = pg_fetch_assoc($result_email);

    // Issue: emails are the same but new user
    if ( $resultCheckRows_username == 0 && $resultCheckRows_email > 0 ) {
        
        // Besides itself
        // if email is already existed then error
        if ( ($row_email['user_id'] != $user_ID) ){
            $_SESSION['show_update_modal'] = true;
            $_SESSION['isEmailExisted'] = true;
            $_SESSION['existingEmail'] = $row_email['user_email'];
            header("Location: ../display-user-table.php?update=error");
            exit();
        }
        
    } 
    // Issue: usernames are the same but new email
    elseif ($resultCheckRows_username > 0 && $resultCheckRows_email == 0 ) {
        
        // if username is already existed then error
        if ( ($row_username['user_id'] != $user_ID) ){
            $_SESSION['show_update_modal'] = true;
            $_SESSION['isUsernameExisted'] = true;
            $_SESSION['existingUsername'] = $row_username['user_username'];
            header("Location: ../display-user-table.php?update=error-----");
            exit();
        }
    } 
    
    // Issue: both emails and uesrnames are existed -> check if valid user
    elseif ($resultCheckRows_username > 0 && $resultCheckRows_email > 0 ) {
        
        // Besides itself
        // if both username and email are existed
        if ( ($row_username['user_id'] != $user_ID) && ($row_email['user_id'] != $user_ID) ) {
            $_SESSION['show_update_modal'] = true;
            $_SESSION['isUsernameExisted'] = true;
            $_SESSION['existingUsername'] = $row_username['user_username'];
            $_SESSION['show_update_modal'] = true;
            $_SESSION['isEmailExisted'] = true;
            $_SESSION['existingEmail'] = $row_email['user_email'];
            header("Location: ../display-user-table.php?update=error");
            exit();
        } 
        
        // Besides itself
        // if email is already existed then error
        if ( ($row_email['user_id'] != $user_ID) ){
            $_SESSION['show_update_modal'] = true;
            $_SESSION['isEmailExisted'] = true;
            $_SESSION['existingEmail'] = $row_email['user_email'];
            header("Location: ../display-user-table.php?update=error");
            exit();
        }

        // if username is already existed then error
        if ( ($row_username['user_id'] != $user_ID) ){
            $_SESSION['show_update_modal'] = true;
            $_SESSION['isUsernameExisted'] = true;
            $_SESSION['existingUsername'] = $row_username['user_username'];
            header("Location: ../display-user-table.php?update=error-----");
            exit();
        }
        
    } // End of if
    /****************************************************************************************/
    
       
    // Update a user with/without password
    if(!empty($user_pwd)) {
        //Hashing the password
        $hashedPwd = password_hash($user_pwd, PASSWORD_DEFAULT);
        $sql_update_with_pwd = "UPDATE Users SET user_first = '$user_first', user_last = '$user_last', 
                                user_email = '$user_email', user_type_id = '$user_type_id', user_username = '$user_username', 
                                user_pwd = '$hashedPwd'
                                WHERE user_ID = '$user_ID';";
        $result_update = pg_query($dbconn, $sql_update_with_pwd);
        
        
        // ******************************************************************************** //
        // ************* Log the action taken ********************************************* //
        // ******************************************************************************** //
        $sql_log = "INSERT INTO User_logs (user_ID, role, user_username, action_taken)
                                VALUES (".$_SESSION['u_id'].", '".$_SESSION['u_type_name']."',
                                '".$_SESSION['u_username']."','Update user ''" . $user_ID . "'' and password');";
        pg_query($dbconn, $sql_log);
        // ******************************************************************************** //
        // ******************************************************************************** //
        
    } else {
        $sql_update_without_pwd = "UPDATE Users SET user_first = '$user_first', user_last = '$user_last', 
                                   user_email = '$user_email', user_type_id = '$user_type_id', user_username = '$user_username'
                                   WHERE user_ID = '$user_ID';";
        $result_update = pg_query($dbconn, $sql_update_without_pwd);
        
        // ******************************************************************************** //
        // ************* Log the action taken ********************************************* //
        // ******************************************************************************** //
        $sql_log = "INSERT INTO User_logs (user_ID, role, user_username, action_taken)
                                VALUES (".$_SESSION['u_id'].", '".$_SESSION['u_type_name']."',
                                '".$_SESSION['u_username']."','Update user ''" . $user_ID . "'' ');";
        pg_query($dbconn, $sql_log);
        // ******************************************************************************** //
        // ******************************************************************************** //

    }
    
    // Check query error
    if (!$result_update) {
        echo "An error occurred.\n";
        exit();
    } 
   
    
    header("Location: ../display-user-table.php?update=success");
    exit();
         
} else {
    header("Location: ../display-user-table.php?update-user=fail");
    exit();
}
?>
    