<?php 
session_start();
include_once './redirect-to-index.inc.php';

if (isset($_POST['logout'])) {
    session_start();

    // ******************************************************************************** //
    // ************* Log the action taken ********************************************* //
    // ******************************************************************************** //
    // Connect to the databaase 
    include_once 'dbh.inc.php';
    $sql_log = "INSERT INTO User_logs (user_ID, role, user_username, action_taken) 
                VALUES (".$_SESSION['u_id'].", '".$_SESSION['u_type_name']."', '".$_SESSION['u_username']."','Logged out');";
    pg_query($dbconn, $sql_log);
    // ******************************************************************************** //
    // ******************************************************************************** //
    
    pg_close($dbconn);
    session_unset();
    session_destroy();
    header("Location: ../index.php?Logout=success");
    exit();
} else {
    header("Location: ../index.php?attempt=fails");
    exit();
}

?>