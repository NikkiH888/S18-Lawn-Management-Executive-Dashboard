<?php
session_start();

// Check if the username is set, then redirect -to- index page
include_once './redirect-to-index.inc.php';

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT p.priority, COUNT(*)
        FROM Issues i
        JOIN Priority p ON i.issuePriority_ID = p.issuePriority_ID
        JOIN Issue_status iss ON i.issueStatus_ID = iss.issueStatus_ID
        WHERE iss.issueStatus_name = 'Past_Due'
        GROUP BY p.priority;";

$result = pg_query($dbconn,  $sql);

if (!$result) {
    echo "An error occurred.\n";
    exit;
}

?>

<script type="text/javascript">
    window.onload = function () {

        CanvasJS.addColorSet("pieShades",
        [//colorSet Array
            "#FF0000", //Red
            "#FF8C00", //DarkOrange
            "#1E90FF", //ligtBlue
            "#008000"  //green
        ]);

        var chart = new CanvasJS.Chart("chartContainer",
        {
            colorSet: "pieShades",
            
            theme: "theme2",
            title:{
                text: ""
            },
            data: [
                {       
                    type: "pie",
                    showInLegend: true,
                    toolTipContent: "{y} - #percent %",
                    yValueFormatString: "# Issues",
                    legendText: "{indexLabel}",
                    dataPoints: [
                        
                        <?php
                        while($row = pg_fetch_array($result, null, PGSQL_NUM)) {
                             echo '{y: ' . $row[1] . ',  label: "' . $row[0] . '"},';
                            
                        } // End of while loop
                        ?>
                        
           
                        
                       
                    ]
                }
            ]
        });
        chart.render();
    }
</script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>