<?php
session_start();
include_once './includes/redirect-to-index.inc.php';

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql_manager = "SELECT B.branch_id, B.branch_name, E.employee_name  
                FROM Branch B, Employee E
                WHERE E.employee_ID = B.branchmanager_id
                ORDER BY B.branch_id;";

$result_manager = pg_query($dbconn, $sql_manager);

//Check query error
if (!$result_manager) {
    echo "An error occurred. --Manager\n";
    exit;
}
?>


<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">

    google.charts.load('current', {'packages':['corechart', 'table', 'bar', 'gauge', 'controls']});

    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(drawMainDashboard_manager);

    function drawMainDashboard_manager() {

        var dashboard = new google.visualization.Dashboard(
            document.getElementById('dashboard_div_manager'));

        var categoryPicker_manager = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryPicker_div_manager',
            'options': {
                'filterColumnIndex': 1,
                'ui': {

                    'label': 'Branch Selection:',
                    'caption': 'All',
                    'allowTyping': false,
                    'allowMultiple': false,
                }
            }
        });

        var table_manager = new google.visualization.ChartWrapper({
            'chartType': 'Table',
            'containerId': 'table_div_manager',
            'options': {
                'title': 'Countries',
                'width': 400,
                'height': 160,

            }
        });

        var data_manager = google.visualization.arrayToDataTable([
            ['Branch ID', 'Branch', 'Manager'],
            <?php
            while($row_manager = pg_fetch_array($result_manager))
            {
                echo "['" .$row_manager[0]. "', '" .$row_manager[1]. "','" . $row_manager[2] . "'],";
            }
            ?>
        ]);

        dashboard.bind(categoryPicker_manager, table_manager);
        dashboard.draw(data_manager);
    }

</script>

<style>
    .google-visualization-table-td {
        text-align: center !important;
    }
</style> 




