<?php
session_start();
include_once './redirect-to-dashboard.inc.php';

if (isset($_POST['login'])) {
    
    // Connect to the databaase 
    include_once 'dbh.inc.php';
        
    // Escape the text data
    $username = pg_escape_string($dbconn, $_POST['username']);
    $user_pwd = pg_escape_string($dbconn, $_POST['user_pwd']);
      
    // UPDATE Admin password
    //$hashedPwd = password_hash($user_pwd, PASSWORD_DEFAULT);
    //$sql = "UPDATE Users SET user_pwd = '$hashedPwd' WHERE user_username = 'admin_username';";
    //$result = pg_query($dbconn, $sql);

    // Error handlers
    // Check for empty fields
    if (empty($username) || empty($user_pwd)){
        header("Location: ../index.php?login=empty");
        exit();
    } else {
        
        $sql = "SELECT * FROM users U JOIN User_types UT ON U.user_type_ID = UT.user_type_ID WHERE U.user_username = '$username' OR U.user_email = '$username';";
        $result = pg_query($dbconn, $sql);
        
        // Check query error
        if (!$result) {
          echo "An error occurred. -- select user query\n";
          exit;
        }
        
        // Get the results from the query
        $resultCheckRows = pg_num_rows($result);
        //echo "<br>" . $resultCheckRows . " row(s) returned.\r\n"; // DEBUG
        
        // Check if the username matches any row in user_username field. 
        if ($resultCheckRows < 1){ 
            // if no username matching         
            echo "<script>alert('Enter valid username/e-mail and password.');document.location='../index.php? login=error.user.not.found'</script>";
            exit();
        } else {
            // if username exists in the database
            if ($row = pg_fetch_assoc($result)) {
                // De-hashing the password
                $hashedPwdCheck = password_verify($user_pwd, $row['user_pwd']);
                // Check if the password correct
                if ($hashedPwdCheck == false) {
                    echo "<script>alert('Enter valid username/e-mail and password.');document.location='../index.php? login=error.user.not.found'</script>";
                    exit();
                }  elseif($hashedPwdCheck == true){
                    // Log in the user here
                    $_SESSION['u_id'] = $row['user_id'];
                    $_SESSION['u_username'] = $row['user_username'];
                    $_SESSION['u_first'] = $row['user_first'];
                    $_SESSION['u_last'] = $row['user_last'];
                    $_SESSION['u_pwd'] = $row['user_pwd'];
                    $_SESSION['u_email'] = $row['user_email'];
                    $_SESSION['u_type_id'] = $row['user_type_id'];
                    $_SESSION['u_type_name'] = $row['user_type_name'];
                         
                    // Get the user type of a user
                    $sql = "SELECT * FROM User_types WHERE user_type_id = '" . pg_escape_string($_SESSION['u_type_id']) . "';";
                    $result = pg_query($dbconn, $sql);
                    if (!$result) {
                      echo "An error occurred.\n";
                      exit;
                    }
                    
                    // ******************************************************************************** //
                    // ************* Log the action taken ********************************************* //
                    // ******************************************************************************** //
                    $sql_log = "INSERT INTO User_logs (user_ID, role, user_username, action_taken)
                                VALUES (".$_SESSION['u_id'].", '".$_SESSION['u_type_name']."',
                                '".$_SESSION['u_username']."','Logged in');";
                    pg_query($dbconn, $sql_log);
                    // ******************************************************************************** //
                    // ******************************************************************************** //
                    
                    // Redirect to excutive-dashboard page
                    header("Location: ../dashboard.php?login=success");
                    exit();
                }          
            }
        }
    }
} else {
    header("Location: ../index.php?login=error");
    exit();
}
?>