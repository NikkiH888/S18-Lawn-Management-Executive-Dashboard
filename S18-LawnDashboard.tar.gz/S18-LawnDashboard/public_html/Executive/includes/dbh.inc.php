<?php

if ( isset($_POST['login']) || isset($_SESSION['u_username']) ) {

    $conn_string = "host=dbase.dsa.missouri.edu dbname=s18dbmsgroups user=s18group01 password=group1";
    // Connect to the database
    $dbconn = pg_connect($conn_string);

    // Check connection status
    $stat = pg_connection_status($dbconn);
    if ($stat === PGSQL_CONNECTION_OK) {
        //echo 'Connection status ok';
    } else {
        //echo 'Connection status bad';
    }
} else {
    header("Location: ../index.php?login=error");
    exit();
}
?>