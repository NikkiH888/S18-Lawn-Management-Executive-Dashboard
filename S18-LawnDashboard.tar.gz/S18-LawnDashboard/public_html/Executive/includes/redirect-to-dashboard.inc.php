<?php

session_start();

// Check if username is set, then redirect -to- dashboard page
if(isset($_SESSION['u_username'])) {
    header("Location: /~bhv39/Executive/dashboard.php?login=already");
    exit();
}
?>