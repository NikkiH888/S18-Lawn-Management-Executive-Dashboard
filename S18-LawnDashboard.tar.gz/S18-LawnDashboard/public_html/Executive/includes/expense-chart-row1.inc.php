<?php
session_start(); // to access global variables
include_once './includes/redirect-to-index.inc.php';        

//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT SUM(actLabor_expense) AS Labor, SUM(actSubcontractor_expense) AS Subcontractor, SUM(actMaterial_expense) AS 
        Material, SUM(actEquipment_expense) AS Equipment
        FROM ticket";

$sql2 = "SELECT SUM(estLabor_expense) AS Labor, SUM(estSubcontractor_expense) AS Subcontractor, SUM(estMaterial_expense) AS 
        Material, SUM(estEquipment_expense) AS Equipment
        FROM ticket";



$result = pg_query($dbconn, $sql);
$result2 = pg_query($dbconn, $sql2);

//Check query error
if (!$result || !$result2) {
    echo "An error occurred.\n";
    exit;
}
?>

<script type="text/javascript">
    window.onload = function () {

        CanvasJS.addColorSet("barShades1",
        [//colorSet Array
            "#800000",
            "#800000"
        ]);
        
     
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        var actual_expense_pie_chart = new CanvasJS.Chart("actual-expense-pie-chart",
        {
            legend:{
                verticalAlign: "bottom",
                horizontalAlign: "center"
            },
            data: [
                {
                    //startAngle: 45,
                    indexLabelFontSize: 20,
                    indexLabelFontFamily: "Garamond",
                    indexLabelFontColor: "darkgrey",
                    indexLabelLineColor: "darkgrey",
                    indexLabelPlacement: "outside",
                    type: "doughnut",
                    dataPoints: [
                        
                        
                            
                    <?php

                        $row = pg_fetch_array($result, null, PGSQL_BOTH);
                        
                        $labor = $row["labor"];
                        $subcontractor = $row["subcontractor"];
                        $material = $row["material"];
                      $equipment = $row["equipment"];
                                      $total = $labor + $subcontractor + $material + $equipment;
                        $laborPercent = number_format($labor / $total * 100,2);
                        $subcontractorPercent = number_format ($subcontractor / $total * 100,2);
                        $materialPercent = number_format($material / $total * 100,2);
                        $equipmentPercent = number_format($equipment / $total *100,2);
                        
                       echo  " {  y: " . $labor . ", indexLabel: 'Labor " . $laborPercent . "%' },
                        {  y: " . $row["subcontractor"] . ", indexLabel: 'Subcontractor " . $subcontractorPercent . "%' },
                        {  y: " . $row["material"] . ", indexLabel: 'Material " . $materialPercent . "%' },
                        {  y: " . $row["equipment"] . ", indexLabel: 'Equipment " . $equipmentPercent . "%' },";
                        
                    
                    ?>
                        

                    ]
                }
            ]
        });
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------       
        var estimated_expense_pie_chart = new CanvasJS.Chart("estimated-expense-pie-chart",
         {

            legend:{
                verticalAlign: "bottom",
                horizontalAlign: "center"
            },
            data: [
                {
                    
                    //startAngle: 45,
                    indexLabelFontSize: 20,
                    indexLabelFontFamily: "Garamond",
                    indexLabelFontColor: "darkgrey",
                    indexLabelLineColor: "darkgrey",
                    indexLabelPlacement: "outside",
                    type: "doughnut",
                    dataPoints: [
                        
                        
                   <?php

                        $row = pg_fetch_array($result2, null, PGSQL_BOTH);
                        
                        $labor = $row["labor"];
                        $subcontractor = $row["subcontractor"];
                        $material = $row["material"];
                      $equipment = $row["equipment"];
                                      $total = $labor + $subcontractor + $material + $equipment;
                        $laborPercent = number_format($labor / $total * 100,2);
                        $subcontractorPercent = number_format ($subcontractor / $total * 100,2);
                        $materialPercent = number_format($material / $total * 100,2);
                        $equipmentPercent = number_format($equipment / $total *100,2);
                        
                       echo  " {  y: " . $labor . ", indexLabel: 'Labor " . $laborPercent . "%' },
                        {  y: " . $row["subcontractor"] . ", indexLabel: 'Subcontractor " . $subcontractorPercent . "%' },
                        {  y: " . $row["material"] . ", indexLabel: 'Material " . $materialPercent . "%' },
                        {  y: " . $row["equipment"] . ", indexLabel: 'Equipment " . $equipmentPercent . "%' },";
                        
                    
                    ?>
                        
                    ]
                }
            ]
        });
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
     
        actual_expense_pie_chart.render();
        estimated_expense_pie_chart.render();
       
    }
</script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>