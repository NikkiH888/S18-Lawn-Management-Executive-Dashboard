<?php
    session_start();
    // Check if the username is set, then redirect -to- dashboard page
    if(!isset($_SESSION['u_username'])) {
        header("Location: ../../homepage-index.php?access=failed");
        exit();
    }




//Connect to the databaase 
include_once 'dbh.inc.php';

$sql = "SELECT contractYear, SUM(sale_price), SUM(actualCost)
        FROM Contract 
        GROUP BY contractYear
        ORDER BY ContractYear ASC;";

$sql2 = "SELECT MIN(contractYear), MAX(contractYear)
        FROM contract;";

$result = pg_query($dbconn, $sql);
$result2 = pg_query($dbconn, $sql2);

//Check query error
if (!$result || !$result2) {
    echo "An error occurred.\n";
    exit;
}

?>


<style>
.vl {
    border-left: 1px solid black;
    height: 50px;
}
</style>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">

    // Load the Visualization API and the controls package.
    // Packages for all the other charts you need will be loaded
    // automatically by the system.
    google.charts.load('current', {'packages':['corechart', 'table', 'bar', 'gauge', 'controls']});

    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(drawMainDashboard);

    // Callback that creates and populates a data table,
    // instantiates a dashboard, a range slider and a pie chart,
    // passes in the data and draws it.
    function drawMainDashboard() {

        var dashboard = new google.visualization.Dashboard(
            document.getElementById('dashboard_div_company'));

        var control_company = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryFilter_control_div_company',
            'options': {
                'filterColumnIndex': 0,
                'ui': {
                    'label': 'Year Selection:',
                    'allowTyping': false,
                    'allowMultiple': true,
                    'selectedValuesLayout': 'aside'
                }
            }
        });


        var categoryPicker_company = new google.visualization.ControlWrapper({
            'controlType': 'CategoryFilter',
            'containerId': 'categoryPicker_div_company',
            'options': {
                'filterColumnIndex': 0,
                'ui': {

                    'label': 'Year Selection:',
                    'caption': 'All Years',
                    'allowTyping': false,
                    'allowMultiple': false,
                    'selectedValuesLayout': 'belowWrapping'
                }
            }
        });

        var column_company = new google.visualization.ChartWrapper({
            'chartType': 'Bar',
            'containerId': 'chart_div_company',
            'options': {
                bars: 'horizontal',
                chart: {
                    title: 'Company Performance',
                    subtitle: 'Sales and Expenses: <?php $row = pg_fetch_array($result2);
                    echo $row[0] . '-' . $row[1]; ?>',
                },
                'width': 650,
                'height': 400,          
            },
            'view': {'columns': [0, 1, 2]}
        });



        var data_company = google.visualization.arrayToDataTable([
            ['Year', '$Revenue', '$Expense'],
            <?php
            while($row = pg_fetch_array($result))
            {
                echo "['" . $row[0] . "', '" . number_format($row[1],2) . "'," . $row[2] . "],";
            }
            ?>
           
        ]);


        dashboard.bind(control_company,column_company);
        dashboard.draw(data_company);
    }


</script>
<style>
    .google-visualization-table-td {
        text-align: center !important;
    }
</style>
        
        
        
        